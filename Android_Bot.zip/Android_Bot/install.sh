#!/data/data/com.termux/files/usr/bin/bash
# ==========================================
# 🔥 VC FIGHTER - LITE & FAST INSTALLER 🔥
# ==========================================
set -e

echo "=================================================="
echo "      🔥 VC FIGHTER - FAST INSTALLER 🔥         "
# Targeted Environment: Python 3.10
echo "=================================================="

echo ""
echo "[1/3] Setting up Repositories..."
pkg update -y
pkg install -y tur-repo

echo ""
echo "[2/3] Installing System Essentials..."
# Grouped install for speed
pkg install -y python3.10 clang ffmpeg portaudio libopenblas libcrypt libjpeg-turbo libsndfile

echo ""
echo "[3/3] Installing Python Modules (3.10)..."
python3.10 -m pip install --upgrade pip wheel setuptools --quiet

# Robust PyAudio & Core deps installation
echo "[+] Compiling dependencies (Optimized)..."
CFLAGS="-I/data/data/com.termux/files/usr/include" LDFLAGS="-L/data/data/com.termux/files/usr/lib" python3.10 -m pip install pyaudio numpy pyrogram tgcrypto pytgcalls --prefer-binary --quiet

echo ""
echo "=================================================="
echo "  ✅ FAST SETUP COMPLETE! SETTING PERMISSIONS... "
echo "=================================================="
termux-setup-storage
termux-microphone-record -d 1 >/dev/null 2>&1 || true

echo ""
echo "🔥 STARTING BOT..."
python3.10 userbot.py

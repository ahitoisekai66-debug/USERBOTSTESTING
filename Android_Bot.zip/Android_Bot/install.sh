#!/data/data/com.termux/files/usr/bin/bash
# ==========================================
# 🔥 VC FIGHTER - ULTRA FAST INSTALLER 🔥
# ==========================================
set -e

echo "=================================================="
echo "      🔥 VC FIGHTER - FAST INSTALLER 🔥         "
echo "=================================================="

echo ""
echo "[1/4] Updating Package List..."
pkg update -y

echo ""
echo "[2/4] Installing Pre-compiled Dependencies..."
# Using TUR repo for 10x faster installation (no compilation)
pkg install -y tur-repo
pkg install -y python python-numpy python-pyaudio clang ffmpeg libjpeg-turbo libsndfile portaudio libopenblas libcrypt

echo ""
echo "[3/4] Installing Python Modules..."
python -m pip install --upgrade pip wheel setuptools --quiet
python -m pip install pyrogram tgcrypto pytgcalls --quiet

echo ""
echo "[4/4] Setting Permissions..."
termux-setup-storage
# Trigger microphone permission
termux-microphone-record -d 1 >/dev/null 2>&1 || true

echo ""
echo "=================================================="
echo "   ✅ FAST SETUP COMPLETE! STARTING BOT...      "
echo "=================================================="
echo ""
python userbot.py

# Pyarmor 8.5.12 (trial), 000000, 2026-04-12T22:28:08.105603
from .pyarmor_runtime import __pyarmor__

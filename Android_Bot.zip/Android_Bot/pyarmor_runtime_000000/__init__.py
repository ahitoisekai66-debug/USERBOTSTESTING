# Pyarmor 8.5.12 (trial), 000000, 2026-04-13T06:57:55.016569
from .pyarmor_runtime import __pyarmor__

# Pyarmor 8.5.12 (trial), 000000, 2026-04-13T07:21:49.097634
from .pyarmor_runtime import __pyarmor__
